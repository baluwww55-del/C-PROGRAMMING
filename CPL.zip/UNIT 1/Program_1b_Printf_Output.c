#include<stdio.h>
int main()
{
int a=10;
printf(“Value of a=%d”,a);
return 0;
}
