#include <stdio.h>
int main()
{
    int x;
    printf("Enter the number: ");
    scanf("%d", &x);
    if (x > 0)
    {
        printf("x is positive\n");
    }
    return 0;
}
