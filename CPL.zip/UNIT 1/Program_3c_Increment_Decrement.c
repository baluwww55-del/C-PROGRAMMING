#include <stdio.h>
int main() {
    int i = 5;
    printf("i++ = %d\n", i++);
    printf("++i = %d\n", ++i);
    printf("i-- = %d\n", i--);
    printf("--i = %d\n", --i);
    return 0;
}
