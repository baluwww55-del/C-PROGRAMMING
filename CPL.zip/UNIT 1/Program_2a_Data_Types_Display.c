#include <stdio.h>
int main() {
    int a = 10;
    float b = 3.14;
    double c = 12.3456789;
    char d = 'X';
    printf("Integer value: %d\n", a);
    printf("Float value: %.2f\n", b);
    printf("Double value: %.9f\n", c);
    printf("Character value: %c\n", d);
    return 0;
}
